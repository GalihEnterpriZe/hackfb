# FACEBOOK CRACKER
![FACEBOOK CRACKER](https://github.com/zettamus/facebook-cracker/blob/master/mbf.jpg?raw=true)
## How to install

```
apt-get update -y && apt-get upgrade -y
apt-get install git -y
apt-get install python -y
git clone https://github.com/zettamus/facebook-cracker
cd facebook-cracker
pip install requests bs4
python mbf.py
```
## If you don't have a data to access internet
## Trying 
```
python mbf.py free
```

# Features

* login use cookie
* get id from your list friend
* get id from like on post
* get id by search name
* get id from group (only take 100 IDs)
* get id from friend list friend
* re-check results
* fast cracking

# version
## 1.0
* first version

## 1.1
* fixed password bugs
* add banner
* add features get user from hashtag
------
